(() => {

})()

const {} = Swal.fire({
  title: 'Hola, Bienvenido a Atory Solutions',
  icon: 'info',
  width: '40%',
  padding: 0,
  background: '#34495E',
  position: 'center',
  allowOutsideClick: false,
  confirmButtonColor: '#3498DB'
});